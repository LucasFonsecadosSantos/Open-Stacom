package com.openstacom.openstacom;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class OpenStacomApplication {

	public static void main(String[] args) {
		SpringApplication.run(OpenStacomApplication.class, args);
	}

}
