package com.openstacom.openstacom;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class OpenStacomApplicationTests {

	@Test
	void contextLoads() {
	}

}
